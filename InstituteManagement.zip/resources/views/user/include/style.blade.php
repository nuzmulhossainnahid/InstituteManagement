<!-- Favicon -->
<link rel="shortcut icon" href="user/images/favicon.ico" type="image/x-icon">
<link rel="icon" href="user/images/favicon.ico" type="image/x-icon">
<!-- Bootstrap -->
<link rel="stylesheet" href="user/css/assets/bootstrap.min.css">
<!-- Normalize CSS -->
<link rel="stylesheet" href="user/css/assets/normalize.css">
<!-- FontAwesome -->
<link rel="stylesheet" href="user/css/assets/font-awesome.min.css">
<!-- Owl Carousel -->
<link rel="stylesheet" href="user/css/assets/owl.carousel.min.css">
<!-- Magnific Popup -->
<link rel="stylesheet" href="user/css/assets/magnific-popup.css">
<!-- Animate CSS -->
<link rel="stylesheet" href="user/css/assets/animate.css">
<!-- Mean Menu -->
<link rel="stylesheet" href="user/css/assets/meanmenu.css">
<!-- Revolution Slider -->
<link rel="stylesheet" href="user/css/assets/revolution/layers.css">
<link rel="stylesheet" href="user/css/assets/revolution/navigation.css">
<link rel="stylesheet" href="user/css/assets/revolution/settings.css">
<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500%7CRoboto+Slab:300,500,400,700" rel="stylesheet">
<!-- Slick Carousel -->
<link rel="stylesheet" href="user/css/assets/slick.css">

<link rel="stylesheet" href="user/css/style.css">
<link rel="stylesheet" href="user/css/assets/responsive.css">

<!-- CSS FOR DEMO - NOT INCLUDED IN MAIN FILES -->
<link rel="stylesheet" href="user/demo/demo.css">