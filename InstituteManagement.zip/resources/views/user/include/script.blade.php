<!-- jQuery -->
<script src="user/../../code.jquery.com/jquery-1.12.0.min.js"></script>
<script>window.jQuery || document.write('<script src="user/js/assets/vendor/jquery-1.12.0.min.js"><\/script>')</script>
<!-- Bootstrap -->
<script src="user/js/assets/bootstrap.min.js"></script>
<!-- Owl Carousel -->
<script src="user/js/assets/owl.carousel.min.js"></script>
<!-- Revolution Slider -->
<script src="user/js/assets/revolution/jquery.themepunch.revolution.min.js"></script>
<script src="user/js/assets/revolution/jquery.themepunch.tools.min.js"></script>
<!-- Magnific Popup -->
<script src="user/js/assets/jquery.magnific-popup.min.js"></script>
<!-- Countdown JS -->
<script src="user/js/assets/jquery.syotimer.min.js"></script>
<!-- Sticky JS -->
<script src="user/js/assets/jquery.sticky.js"></script>
<!-- Slick Carousel -->
<script src="user/js/assets/slick.min.js"></script>
<!-- Mean Menu -->
<script src="user/js/assets/jquery.meanmenu.min.js"></script>
<!-- Mail JS -->
<script src="js/assets/mail.js"></script>
<!-- Revolution Extensions -->
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="user/js/assets/revolution/extensions/revolution.extension.video.min.js"></script>

<!-- Custom JS -->
<script src="user/js/plugins.js"></script>
<script src="user/js/custom.js"></script>

<!-- =========================================================
     STYLE SWITCHER | ONLY FOR DEMO NOT INCLUDED IN MAIN FILES
============================================================== -->
<script type="text/javascript" src="user/demo/demo.js"></script>