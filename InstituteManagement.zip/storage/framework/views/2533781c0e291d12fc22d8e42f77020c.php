<header>
    <!-- Header Top -->
    <div class="header-top header-top-dark">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-xs-12 header-top-left">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-map-marker"></i> Seventh Avenue New York</li>
                        <li><i class="fa fa-phone"></i> +123 456 789</li>
                        <li><i class="fa fa-envelope"></i> hello@edulight.com</li>
                    </ul>
                </div>
                <div class="col-sm-6 col-xs-12 header-top-right">
                    <ul class="list-unstyled">
                        <li><a href="#">Register</a></li>
                        <li><a href="#">Login</a></li>
                        <li><a href="#" class="apply-btn">Apply Now</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div><!-- Ends: .header-top -->
    <div class="main-menu">
        <div class="container">
            <div class="row">
                <!-- Main Menu -->
                <div class="col-sm-12">
                    <nav class="navbar" id="main-nav">
                        <div class="containers">
                            <div class="navbar-header">
                                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#edulight-navbar-collapse" aria-expanded="false">
                                    <span class="sr-only">Toggle navigation</span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <!-- Change Logo Here -->
                                <a class="navbar-brand" href="index.html"><img src="user/images/logo.png" alt="EduLight"></a>
                            </div><!-- End .navbar-header -->

                            <!-- Fullscreen search -->
                            <div class="search-wrap">
                                <div class="search-inner">
                                    <div class="search-cell">
                                        <form method="get">
                                            <div class="search-field-holder">
                                                <input type="search" class="form-control main-search-input" placeholder="Search ...">
                                                <button type="submit"><i class="fa fa-search"></i></button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div> <!-- end fullscreen search -->

                            <div class="nav-container">
                                <div class="menu-search">
                                    <ul class="list-unstyled">
                                        <li class="hidden-xs">
                                            <ul class="list-unstyled">
                                                <li class="nav-search-wrap hidden-xs">
                                                    <a href="#" class="nav-search search-trigger">
                                                        <i class="fa fa-search"></i>
                                                    </a>
                                                </li>
                                            </ul>
                                        </li><!-- Ends .nav-right -->
                                    </ul>
                                </div>
                                <div class="collapse navbar-collapse" id="edulight-navbar-collapse">
                                    <ul class="nav navbar-nav">
                                        <li class="mega-menu dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Demos</a>
                                            <ul class="mega-menu-block list-unstyled dropdown-menu">
                                                <li>
                                                    <div class="mega-menu-content clearfix">
															<span class="mega-content-block">
																<a href="01-main-demo.html">Main Demo</a>
																<a href="02-edulight-default-one.html">Edulight Default One</a>
																<a href="03-edulight-default-two.html">Edulight Default Two</a>
																<a href="04-course-hub-v1.html">Course Hub One</a>
																<a href="05-course-hub-v2.html">Course Hub Two</a>
															</span>
                                                        <span class="mega-content-block">
																<a href="08-university-v1.html">University One</a>
																<a href="09-university-v2.html">University Two</a>
																<a href="11-dance-school.html">Dance School</a>
																<a href="13-online-school.html">Online School</a>
																<a href="14-language-club.html">Language Club</a>
															</span>
                                                        <span class="mega-content-block">
																<a href="15-single-course.html">Single Course</a>
																<a href="06-kindergarten-v1.html">Kindergarten One</a>
																<a href="07-kindergarten-v2.html">Kindergarten Two</a>
																<a href="10-single-instructor.html">Single Instructor</a>
																<a href="12-driving-school.html">Driving School</a>
															</span>
                                                        <span class="mega-content-block">
																<a href="coming-soon.html">Coming Soon</a>
																<a href="404.html">404 Page</a>
															</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </li><!-- End .mega-menu -->
                                        <li class="mega-menu dropdown"><a href="#" class="dropdown-toggle" data-toggle="dropdown">Courses</a>
                                            <ul class="mega-menu-block list-unstyled dropdown-menu">
                                                <li>
                                                    <div class="mega-menu-content clearfix">
															<span class="mega-content-block">
																<a href="courses-01.html">Courses One</a>
																<a href="courses-02.html">Courses Two</a>
																<a href="courses-03.html">Courses Three</a>
																<a href="courses-04.html">Courses Four</a>
																<a href="courses-05.html">Courses Five</a>
															</span>
                                                        <span class="mega-content-block">
																<a href="courses-06.html">Courses Six</a>
																<a href="course-single.html">Course Single</a>
																<a href="#">Page One</a>
																<a href="#">Page Two</a>
																<a href="#">Page Three</a>
															</span>
                                                        <span class="mega-content-block">
																<a href="#">Page Four</a>
																<a href="#">Page Five</a>
																<a href="#">Page Six</a>
																<a href="#">Page Seven</a>
																<a href="#">Page Eight</a>
															</span>
                                                        <span class="mega-content-block">
																<img src="user/images/megamenu.jpg" alt="" class="img-responsive" />
															</span>
                                                    </div>
                                                </li>
                                            </ul>
                                        </li><!-- End .mega-menu -->
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Teacher</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="teachers-01.html">Teacher One</a></li>
                                                <li><a href="teachers-02.html">Teacher Two</a></li>
                                                <li><a href="teachers-03.html">Teacher Three</a></li>
                                                <li><a href="teachers-04.html">Teacher Four</a></li>
                                                <li><a href="teachers-05.html">Teacher Five</a></li>
                                                <li><a href="teachers-06.html">Teacher Six</a></li>
                                                <li><a href="teachers-07.html">Teacher Seven</a></li>
                                                <li><a href="teacher-single.html">Teacher Single</a></li>
                                            </ul>
                                        </li><!-- End Teacher -->
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Events</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="events-01.html">Event One</a></li>
                                                <li><a href="events-02.html">Event Two</a></li>
                                                <li><a href="events-03.html">Event Three</a></li>
                                                <li><a href="event-details.html">Event Details</a></li>
                                            </ul>
                                        </li><!-- End Pages -->
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Pages</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="about-us.html">About Us</a></li>
                                                <li><a href="become-a-teacher.html">Become A Teacher</a></li>
                                                <li><a href="faqs.html">FAQ</a></li>
                                                <li><a href="forum.html">Forum</a></li>
                                                <li class="dropdown-submenu">
                                                    <a href="#">Gallery</a>
                                                    <i class="fa fa-angle-right"></i>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="gallery-three-column.html">Gallery Three Column</a></li>
                                                        <li><a href="gallery-four-column.html">Gallery Four Column</a></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown-submenu">
                                                    <a href="#">Portfolio</a>
                                                    <i class="fa fa-angle-right"></i>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="portfolio-two-column.html">Portfolio Two Column</a></li>
                                                        <li><a href="portfolio-three-column.html">Portfolio Three Column</a></li>
                                                        <li><a href="portfolio-four-column.html">Portfolio Four Column</a></li>
                                                    </ul>
                                                </li>
                                                <li><a href="coming-soon.html">Coming Soon</a></li>
                                                <li><a href="404.html">404</a></li>
                                            </ul>
                                        </li><!-- End Pages -->
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Blog</a>
                                            <ul class="dropdown-menu">
                                                <li class="dropdown-submenu">
                                                    <a href="#">Classic</a>
                                                    <i class="fa fa-angle-right"></i>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="blog-03.html">Blog One</a></li>
                                                        <li><a href="blog-04.html">Blog Two</a></li>
                                                        <li><a href="blog-05.html">Blog Three</a></li>
                                                        <li><a href="blog-06.html">Blog Four</a></li>
                                                        <li><a href="blog-07.html">Blog Five</a></li>
                                                        <li><a href="blog-08.html">Blog Six</a></li>
                                                        <li><a href="blog-09.html">Blog Seven</a></li>
                                                        <li><a href="blog-10.html">Blog Eight</a></li>
                                                    </ul>
                                                </li>
                                                <li class="dropdown-submenu">
                                                    <a href="#">Fullwidth</a>
                                                    <i class="fa fa-angle-right"></i>
                                                    <ul class="dropdown-menu">
                                                        <li><a href="blog-01.html">Blog One</a></li>
                                                        <li><a href="blog-02.html">Blog Two</a></li>
                                                    </ul>
                                                </li>
                                                <li>
                                                    <a href="blog-details.html">Blog Details</a>
                                                </li>
                                            </ul>
                                        </li> <!-- end gallery -->
                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown">Contact</a>
                                            <ul class="dropdown-menu">
                                                <li><a href="contact-01.html">Contact One</a></li>
                                                <li><a href="contact-02.html">Contact Two</a></li>
                                                <li><a href="contact-03.html">Contact Three</a></li>
                                            </ul>
                                        </li><!-- End Contact -->

                                        <li><a href="shop.html">Shop</a></li>

                                    </ul>
                                </div><!-- .navbar-collapse -->
                            </div><!-- Ends: .nav-container -->

                        </div><!-- .container -->
                    </nav>
                </div>
            </div>
        </div>
    </div><!-- Ends: .main-menu -->
</header><!-- ends: Header -->
<?php /**PATH J:\InstituteManagement\InstituteManagement\resources\views/user/include/header.blade.php ENDPATH**/ ?>