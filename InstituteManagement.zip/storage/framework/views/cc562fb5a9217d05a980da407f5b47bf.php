<!doctype html>
<html class="no-js" lang="zxx">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="EduLight - Multipurpose Education Template">
    <meta name="keywords" content="edulight, bootstrap, education template, template">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Edulight - <?php echo $__env->yieldContent('title'); ?></title>

    <?php echo $__env->make('user.include.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div id="preloader">
    <div id="status">&nbsp;</div>
</div>

<!--==================
    Header
===================-->
<?php echo $__env->make('user.include.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>
<!--==================
    Footer
===================-->
<?php echo $__env->make('user.include.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--==================
    JS Files
===================-->
<?php echo $__env->make('user.include.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    
    
        
            
            
            
        
        
            
            
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
            
        
    

</body>

</html>
<?php /**PATH J:\InstituteManagement\InstituteManagement\resources\views/main.blade.php ENDPATH**/ ?>